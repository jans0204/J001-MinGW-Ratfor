# https://rosettacode.org/wiki/Sieve_of_Eratosthenes#RATFOR

program prime
#
define(true,1)
define(false,0)
#
integer loop,loop2,limit,k,primes,count
integer isprime(1000)

limit = 1000
count = 0

for (loop=1; loop<=limit; loop=loop+1)
    {
       isprime(loop) = true
    }

isprime(1) = false

for (loop=2; loop<=limit; loop=loop+1)


    {
       if (isprime(loop) == true)
          {
              count = count + 1
              for (loop2=loop*loop; loop2 <= limit; loop2=loop2+loop)
                 {
                     isprime(loop2) = false
                 }
          }
    }
write(*,*)
write(*,101) count

101 format('There are ',I12,' primes.')

count = 0
for (loop=1; loop<=limit; loop=loop+1)
        if (isprime(loop) == true)
           {
               Count = count + 1
               write(*,'(I6,$)')loop
               if (mod(count,10) == 0) write(*,*)
           }
write(*,*)

end
