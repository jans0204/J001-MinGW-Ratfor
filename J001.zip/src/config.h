
#define PACKAGE_STRING "C Ratfor"

#define S_IRUSR 0400
#define S_IWUSR 0200

#define S_IRGRP 040
#define S_IWGRP 020

#define S_IROTH 04
#define S_IWOTH 02
